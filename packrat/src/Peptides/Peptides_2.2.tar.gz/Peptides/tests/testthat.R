library(testthat)
library(Peptides)

test_check("Peptides")
