#' @useDynLib Peptides, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL